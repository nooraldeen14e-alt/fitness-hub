Client logos cropped from the supplied collage.
Some logo names could not be read confidently and are marked Unknown.
The source image available in this chat contained 24 logos.
